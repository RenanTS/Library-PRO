
TITLE: 
Multipurpose - 100% Fully Responsive Multipurpose Website Template

AUTHOR:
DESIGNED & DEVELOPED by FreeHTML5.co

Website: https://freehtml5.co/
Twitter: https://twitter.com/fh5co
Facebook: https://facebook.com/fh5co


CREDITS:

Bootstrap
http://getbootstrap.com/

Google Fonts
https://www.google.com/fonts/

jQuery
http://jquery.com/

Owl Carousel
http://www.owlcarousel.owlgraphic.com/

Loaders
https://connoratherton.com/loaders

AOS
https://michalsnik.github.io/aos/

Swiper
http://www.idangero.us/swiper/

lightgallery
http://sachinchoolur.github.io/lightGallery/

Demo Images:
https://unsplash.com
https://pexels.com
https://lorempixel.com

